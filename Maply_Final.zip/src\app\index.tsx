import { StatusBar } from 'expo-status-bar';
import React from 'react';
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

// NOTA PARA CUANDO ESTÉS EN TU CASA:
// Para usar el mapa real en el celular, descomenta la línea de abajo y borra el simulador.
// import MapView, { Marker } from 'react-native-maps';

const reports = [
  {
    id: 1,
    type: 'Hospital',
    title: 'Guardia saturada',
    place: 'Hospital Fernández',
    time: 'Hace 12 min',
    coordinates: { latitude: -34.5824, longitude: -58.4079 },
  },
  {
    id: 2,
    type: 'Transporte',
    title: 'Parada movida',
    place: 'Av. Santa Fe',
    time: 'Hace 5 min',
    coordinates: { latitude: -34.5862, longitude: -58.4031 },
  },
  {
    id: 3,
    type: 'Tránsito',
    title: 'Choque y demora',
    place: '9 de Julio',
    time: 'Hace 20 min',
    coordinates: { latitude: -34.5986, longitude: -58.3816 },
  },
];

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" />

      {/* HEADER */}
      <View style={styles.header}>
        <Text style={styles.logo}>Maply Services</Text>
        <Text style={styles.subtitle}>
          Reportes urbanos en tiempo real
        </Text>
      </View>

      {/* SIMULADOR DE MAPA ELEGANTE (Perfecto para la escuela) */}
      <View style={styles.mapContainer}>
        <View style={styles.webMapPlaceholder}>
          <Text style={styles.placeholderEmoji}>🗺️</Text>
          <Text style={styles.placeholderTitle}>
            Modo Escuela (Simulador)
          </Text>
          <Text style={styles.placeholderSubtitle}>
            Monitoreando {reports.length} zonas críticas en Buenos Aires
          </Text>
          
          {/* Mini indicadores visuales simulando pines del mapa */}
          <View style={styles.miniPinsContainer}>
            <Text style={styles.miniPin}>🏥 Hospital</Text>
            <Text style={styles.miniPin}>🚌 Autobús</Text>
            <Text style={styles.miniPin}>🚗 Tráfico</Text>
          </View>
        </View>
      </View>

      {/* TITULO */}
      <Text style={styles.sectionTitle}>
        Actividad reciente
      </Text>

      {/* CARDS */}
      <ScrollView showsVerticalScrollIndicator={false}>
        {reports.map((report) => (
          <View key={report.id} style={styles.card}>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{report.type}</Text>
            </View>

            <Text style={styles.cardTitle}>{report.title}</Text>
            <Text style={styles.place}>📍 {report.place}</Text>
            <Text style={styles.time}>{report.time}</Text>
          </View>
        ))}
      </ScrollView>

      {/* BOTON */}
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>+ Crear reporte</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0B1120',
    paddingTop: 55,
    paddingHorizontal: 20,
  },

  header: {
    marginBottom: 20,
  },

  logo: {
    color: 'white',
    fontSize: 32,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#94A3B8',
    fontSize: 15,
    marginTop: 4,
  },

  mapContainer: {
    height: 220,
    borderRadius: 25,
    overflow: 'hidden',
    marginBottom: 25,
    borderWidth: 1,
    borderColor: '#1E293B',
    backgroundColor: '#111827',
  },

  webMapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  placeholderEmoji: {
    fontSize: 40,
    marginBottom: 10,
  },

  placeholderTitle: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },

  placeholderSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 5,
    marginBottom: 15,
  },

  miniPinsContainer: {
    flexDirection: 'row',
    gap: 10,
  },

  miniPin: {
    color: '#CBD5E1',
    backgroundColor: '#1E293B',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    fontSize: 11,
    fontWeight: '500',
  },

  sectionTitle: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
  },

  card: {
    backgroundColor: '#111827',
    borderRadius: 22,
    padding: 18,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#1E293B',
  },

  badge: {
    backgroundColor: '#2563EB',
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 999,
    marginBottom: 12,
  },

  badgeText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 12,
  },

  cardTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },

  place: {
    color: '#CBD5E1',
    fontSize: 14,
  },

  time: {
    color: '#64748B',
    fontSize: 12,
    marginTop: 12,
  },

  button: {
    backgroundColor: '#3B82F6',
    padding: 18,
    borderRadius: 20,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 15,
  },

  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
